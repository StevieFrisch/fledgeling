let response;

const mysql = require("mysql");

var con = mysql.createConnection({
  host: "calculatordb.cfj2ikzeeddv.us-east-1.rds.amazonaws.com",
  user: "calcAdmin",
  password: "MoundDay!",
  database: "info"
});

let theWord;

exports.lambdaHandler = async (event, context) => {
    let status;
    let body = {};
    
    
    try {
        
        //console.log(event);
        
        // let actual_event = event.body;
        // let info = JSON.parse(actual_event);
        let info = event;
        
        let em = info.Email;
        
        
        //let em = "matt";
        
        //database stuff \/
        
        let game;
        
        let GetName = (game) => {
            return new Promise((resolve, reject) => {
                con.query("SELECT ID FROM Supporters WHERE Email =?", [game], (error, rows) => {
                    if (error) { return reject(error); }
                    
                    if ((rows) && (rows.length == 1)) {
                        return resolve(rows[0]);   // TRUE if does exist
                    } else { 
                        throw "Supporter doesn't exist";
                        return resolve("");   // FALSE if doesn't exist
                    }
                });
            });
        };

        
        let GetMoney = (money) => {
            return new Promise((resolve, reject) => {
                con.query("SELECT Budget FROM Supporters WHERE ID =?", [money.ID], (error, rows) => {
                    if (error) { return reject(error); }
                    if ((rows) && (rows.length == 1)) {
                        return resolve(rows[0]);   // TRUE if does exist
                    } else { 
                        throw "Supporter doesn't exist";
                        return resolve("");   // FALSE if doesn't exist
                    }
                });
            });
        }
        
        let GetPledges = (game) => {
                return new Promise((resolve, reject) => {
                    con.query("SELECT * FROM Pledges WHERE SupporterID=?", [game.ID], (error, rows) => {
                        if (error) { return reject(error); }
                        if ((rows) && (rows.length != 0)) {
                            return resolve(rows);   // TRUE if does exist
                        } else { 
                            return resolve ([]);
                        }
                    });
                });
            };
            
            
        let GetDonos = (game) => {
            return new Promise((resolve, reject) => {
                con.query("SELECT * FROM Donations WHERE SupporterID=?", [game], (error, rows) => {
                    if (error) { return reject(error); }
                    if ((rows) && (rows.length != 0)) {
                        return resolve(rows);   // TRUE if does exist
                    } else { 
                        return resolve ([]);
                    }
                });
            });
        };
        
        
        let GetProj = (game) => {
            return new Promise((resolve, reject) => {
                con.query("SELECT * FROM Projects WHERE ID=?", [game], (error, rows) => {
                    if (error) { return reject(error); }
                    if ((rows) && (rows.length != 0)) {
                        return resolve(rows[0]);   // TRUE if does exist
                    } else { 
                        throw "Project doesn't exist"
                    }
                });
            });
        };
        
        
        let GetPledge = (game) => {
            return new Promise((resolve, reject) => {
                con.query("SELECT * FROM PledgeTier WHERE ID=?", [game], (error, rows) => {
                    if (error) { return reject(error); }
                    if ((rows) && (rows.length != 0)) {
                        return resolve(rows[0]);   // TRUE if does exist
                    } else { 
                        throw "PledgeTier doesn't exist"
                    }
                });
            });
        };
        
        
        
        
        try {
            theWord = await GetName(em);
            let money = await GetMoney(theWord);
            
            
            //MAKE SURE PROJECT IS ACTIVE BEFORE SHOWING PLEDGE
            
            
            let pledges = await GetPledges(theWord);
            
            body.Funds = money.Budget;
            body.Pledges = [];
            body.Donations = [];
            
            let donos = await GetDonos(theWord.ID);
            for (let donation of donos) {
                let newDono = {};
                newDono.Amount = donation.Amount;
                newDono.ProjectID = donation.ProjectID;
                newDono.ProjectName = (await GetProj(donation.ProjectID)).Name;
                body.Donations.push(newDono);
            }
            
            
            
            for (let curPledge of pledges){
                let newPledge = {};
                //console.log(curPledge);
                let pledgeTier = await GetPledge(curPledge.PledgeTierID);
                newPledge.Amount = pledgeTier.Amount;
                newPledge.Description = pledgeTier.Description;
                newPledge.ProjectID = pledgeTier.ProjectID;
                let curProj = await GetProj(pledgeTier.ProjectID);
                newPledge.ProjectName = curProj.Name;
                newPledge.ProjectIsActive = curProj.IsActive;
                
                if (curProj.IsActive == 1 || curProj.IsActive == 2){
                    body.Pledges.push(newPledge);
                }
                
                
            }
            
            
            
            
        } catch (error) {
            console.log("ERROR: " + error);
            response.statusCode = 400;
            response.error = error;
        }
        
        
        
        //database stuff /\
        
        
       
        
        
    } catch(err){
        status = 400;
        body["error"] = err.toString();
    }
    
    //full response
    response = {
        'statusCode': status,
        
        headers: {
            "Access-Control-Allow-Headers" : "Content-Type",
            "Access-Control-Allow-Origin" : "*", //allow from anywhere
            "Access-Control-Allow-Methods" : "POST" //allow POSTs
        },
        
        'body': JSON.stringify(body),
    };

    return response;
};