let response;

const mysql = require("mysql");
let theWord;

var con = mysql.createConnection({
  host: "calculatordb.cfj2ikzeeddv.us-east-1.rds.amazonaws.com",
  user: "calcAdmin",
  password: "MoundDay!",
  database: "info"
});

exports.lambdaHandler = async (event, context) => {
    let status;
    let body = {};
    
    
    try {
        
        //console.log(event);
        
        let info = event;
        
        let id = info.ID;
        //let em = "matt";
        
        //database stuff \/
        
        let game;
        let GetWord = (game) => {
            return new Promise((resolve, reject) => {
                con.query("SELECT * FROM Projects WHERE ID=?", [id], (error, rows) => {
                    if (error) { return reject(error); }
                    if ((rows) && (rows.length != 0)) {
                        return resolve(rows[0]);   // TRUE if does exist
                    } else { 
                        throw "project doesn't exist";
                    }
                });
            });
        };
        let GetProject = (game) => {
            return new Promise((resolve, reject) => {
                con.query("SELECT * FROM PledgeTier WHERE ProjectID=?", [id], (error, rows) => {
                    if (error) { return reject(error); }
                    if ((rows) && (rows.length != 0)) {
                        return resolve(rows);   // TRUE if does exist
                    } else { 
                        return resolve ([]);
                    }
                });
            });
        };
        
        let GetProjects = (game) => {
            return new Promise((resolve, reject) => {
                con.query("SELECT * FROM Pledges WHERE PledgeTierID=?", [game], (error, rows) => {
                    if (error) { return reject(error); }
                    if ((rows) && (rows.length != 0)) {
                        return resolve(rows);   // TRUE if does exist
                    } else { 
                        return resolve ([]);
                    }
                });
            });
        };
        
        let GetName = (game) => {
            return new Promise((resolve, reject) => {
                con.query("SELECT Email FROM Designers WHERE ID=?", [theWord.DesignerID], (error, rows) => {
                    if (error) { return reject(error); }
                    if ((rows) && (rows.length == 1)) {
                        return resolve(rows[0]);   // TRUE if does exist
                    } else { 
                        throw "designer doesn't exist";
                        return resolve("");   // FALSE if doesn't exist
                    }
                });
            });
        };
        
        try {
            theWord = await GetWord(0);
            let theProj = await GetProject(theWord);
            let returnName = await GetName(theWord);
            
            //console.log(returnName);
            
            //console.log(theWord);
            
            body.ID = id;
            body.Name = theWord.Name;
            body.Description = theWord.Description;
            body.DesignerName = returnName.Email;
            body.IsActive = theWord.IsActive;
            body.Deadline = theWord.Deadline;
            body.Genre = theWord.Genre;
            body.Goal = theWord.Goal;
            body.Amount = 0;
            body.PledgeTiers = theProj;
            
            let prog = 0;
            for (let pledgeTier of theProj) {
                //console.log(pledgeTier);
                let curPledges = await GetProjects(pledgeTier.ID);
                for (let curPledge of curPledges){
                    prog += pledgeTier.Amount;
                    
                }
            }
            
            body.Amount = prog;
            
        } catch (error) {
            console.log("ERROR: " + error);
            response.statusCode = 400;
            response.error = error;
        }
        

        
        
        //let result = db.query("SELECT EXISTS(SELECT * FROM Designers WHERE Email = '" + em + "')" );
        //console.log(result);
        
        
        
        //database stuff /\
        
        
       
        
        
    } catch(err){
        status = 400;
        body["error"] = err.toString();
    }
    
    //full response
    response = {
        'statusCode': status,
        
        headers: {
            "Access-Control-Allow-Headers" : "Content-Type",
            "Access-Control-Allow-Origin" : "*", //allow from anywhere
            "Access-Control-Allow-Methods" : "POST" //allow POSTs
        },
        
        'body': JSON.stringify(body),
    };

    return response;
};