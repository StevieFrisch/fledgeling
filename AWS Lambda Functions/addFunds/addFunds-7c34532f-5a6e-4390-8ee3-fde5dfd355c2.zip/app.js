let response;

const mysql = require("mysql");

var con = mysql.createConnection({
  host: "calculatordb.cfj2ikzeeddv.us-east-1.rds.amazonaws.com",
  user: "calcAdmin",
  password: "MoundDay!",
  database: "info"
});

let theWord;

exports.lambdaHandler = async (event, context) => {
    let status;
    let body = {};
    
    
    try {
        
        //console.log(event);
        
        // let actual_event = event.body;
        // let info = JSON.parse(actual_event);
        let info = event;
        
        let em = info.Email;
        let am = info.Amount;
        
        
        //let em = "matt";
        
        //database stuff \/
        
        let game;
        
        let GetName = (game) => {
            return new Promise((resolve, reject) => {
                con.query("SELECT ID FROM Supporters WHERE Email =?", [game], (error, rows) => {
                    if (error) { return reject(error); }
                    
                    if ((rows) && (rows.length == 1)) {
                        return resolve(rows[0]);   // TRUE if does exist
                    } else { 
                        throw "Supporter doesn't exist";
                        return resolve("");   // FALSE if doesn't exist
                    }
                });
            });
        };

        let SetMoney = (am, game) => {
            return new Promise((resolve, reject) => {
                con.query("UPDATE Supporters SET Budget = ? WHERE ID LIKE ?", [am, game.ID], (error, rows) => {
                    if (error) { return reject(error); }
                    return resolve("");
                });
            });
        };
        
        
        let GetMoney = (money) => {
            return new Promise((resolve, reject) => {
                con.query("SELECT Budget FROM Supporters WHERE ID =?", [money.ID], (error, rows) => {
                    if (error) { return reject(error); }
                    if ((rows) && (rows.length == 1)) {
                        return resolve(rows[0]);   // TRUE if does exist
                    } else { 
                        throw "Supporter doesn't exist";
                        return resolve("");   // FALSE if doesn't exist
                    }
                });
            });
        }
        
        
        
        try {
            //console.log("result: " + theWord);
            theWord = await GetName(em);
            let money = await GetMoney(theWord);
            money = await SetMoney(parseInt(money.Budget, 10) + parseInt(am, 10), theWord);
            money = await GetMoney(theWord);
            
            body.Amount = money.Budget;
            
            
        } catch (error) {
            console.log("ERROR: " + error);
            response.statusCode = 400;
            response.error = error;
        }
        
        
        
        //database stuff /\
        
        
       
        
        
    } catch(err){
        status = 400;
        body["error"] = err.toString();
    }
    
    //full response
    response = {
        'statusCode': status,
        
        headers: {
            "Access-Control-Allow-Headers" : "Content-Type",
            "Access-Control-Allow-Origin" : "*", //allow from anywhere
            "Access-Control-Allow-Methods" : "POST" //allow POSTs
        },
        
        'body': JSON.stringify(body),
    };

    return response;
};