let response;

const mysql = require("mysql");

var con = mysql.createConnection({
  host: "calculatordb.cfj2ikzeeddv.us-east-1.rds.amazonaws.com",
  user: "calcAdmin",
  password: "MoundDay!",
  database: "info"
});

let theWord;

exports.lambdaHandler = async (event, context) => {
    let status;
    let body = {};
    
    
    try {
        
        //console.log(event);
        
        // let actual_event = event.body;
        // let info = JSON.parse(actual_event);
        let info = event;
        
        let em = info.Email;
        
        
        //let em = "matt";
        
        //database stuff \/
        
        let game;
        let GetWord = (game) => {
            return new Promise((resolve, reject) => {
                con.query("SELECT ID FROM Admins WHERE Email=?", [em], (error, rows) => {
                    if (error) { return reject(error); }
                    if ((rows) && (rows.length == 1)) {
                        return resolve(rows[0]);   // TRUE if does exist
                    } else { 
                        throw "Admin doesn't exist";
                        return resolve("");   // FALSE if doesn't exist
                    }
                });
            });
        };
        let GetProject = (game) => {
            return new Promise((resolve, reject) => {
                con.query("SELECT * FROM Projects", [theWord.ID], (error, rows) => {
                    if (error) { return reject(error); }
                    body = rows;
                    return resolve(rows);
                });
            });
        };
        
        
        let GetName = (game) => {
            return new Promise((resolve, reject) => {
                con.query("SELECT Email FROM Designers WHERE ID=?", [game], (error, rows) => {
                    if (error) { return reject(error); }
                    
                    if ((rows) && (rows.length == 1)) {
                        return resolve(rows[0]);   // TRUE if does exist
                    } else { 
                        throw "designer doesn't exist";
                        return resolve("");   // FALSE if doesn't exist
                    }
                });
            });
        };
        
        let UpdateActive = (game, act) => {
            return new Promise((resolve, reject) => {
                con.query("Update Projects SET IsActive = ? WHERE ID=?", [act, game], (error, rows) => {
                    if (error) { return reject(error); }
                    if ((rows) && (rows.length != 0)) {
                        return resolve(rows);   // TRUE if does exist
                    } else { 
                        return resolve ([]);
                    }
                });
            });
        };
        
        let GetDonos = (game) => {
            return new Promise((resolve, reject) => {
                con.query("SELECT * FROM Donations WHERE ProjectID=?", [game], (error, rows) => {
                    if (error) { return reject(error); }
                    if ((rows) && (rows.length != 0)) {
                        return resolve(rows);   // TRUE if does exist
                    } else { 
                        return resolve ([]);
                    }
                });
            });
        };
        
        let GetNames = (game) => {
            return new Promise((resolve, reject) => {
                con.query("SELECT Email FROM Supporters WHERE ID=?", [game], (error, rows) => {
                    if (error) { return reject(error); }
                    if ((rows) && (rows.length == 1)) {
                        return resolve(rows[0]);   // TRUE if does exist
                    } else { 
                        throw "supporter doesn't exist";   // FALSE if doesn't exist
                    }
                });
            });
        };
        
        let GetProjects = (game) => {
            return new Promise((resolve, reject) => {
                con.query("SELECT * FROM Pledges WHERE PledgeTierID=?", [game], (error, rows) => {
                    if (error) { return reject(error); }
                    if ((rows) && (rows.length != 0)) {
                        return resolve(rows);   // TRUE if does exist
                    } else { 
                        return resolve ([]);
                    }
                });
            });
        };
        
        let GetTiers = (game) => {
            return new Promise((resolve, reject) => {
                con.query("SELECT * FROM PledgeTier WHERE ProjectID=?", [game], (error, rows) => {
                    if (error) { return reject(error); }
                    if ((rows) && (rows.length != 0)) {
                        return resolve(rows);   // TRUE if does exist
                    } else { 
                        return resolve ([]);
                    }
                });
            });
        };
        
        
        let SetMoney = (am, game) => {
            return new Promise((resolve, reject) => {
                con.query("UPDATE Supporters SET Budget = ? WHERE ID LIKE ?", [am, game], (error, rows) => {
                    if (error) { return reject(error); }
                    return resolve("");
                });
            });
        };
        
        
        let GetMoney = (money) => {
            return new Promise((resolve, reject) => {
                con.query("SELECT Budget FROM Supporters WHERE ID =?", [money], (error, rows) => {
                    if (error) { return reject(error); }
                    if ((rows) && (rows.length == 1)) {
                        return resolve(rows[0]);   // TRUE if does exist
                    } else { 
                        throw "Supporter doesn't exist";
                        return resolve("");   // FALSE if doesn't exist
                    }
                });
            });
        }
        
        try {
            theWord = await GetWord(0);
            //console.log("result: " + theWord);
            let theProj = await GetProject(theWord);
            
            //let returnName = await GetName(0);
            
            
            let date = new Date().toJSON();
            let time = JSON.stringify(date);
            let year = parseInt(time.substring(1,5), 10);
            let month = parseInt(time.substring(6,8), 10);
            let day = parseInt(time.substring(9,11), 10);
                
                
            for (let project of body){
                let projdate = project.Deadline.toJSON();
                let projyear = parseInt(projdate.substring(0,4), 10);
                let projmonth = parseInt(projdate.substring(5,7), 10);
                let projday = parseInt(projdate.substring(8,10), 10);
                
                if((year >= projyear && month >= projmonth && day >= projday) || (year === projyear && month > projmonth) || (year > projyear)){
                    
                    //console.log(projdate);
                    let prog = 0;
                    let tiers = await GetTiers(project.ID);
                    for (let pledgeTier of tiers) {
                        //console.log(pledgeTier);
                        let curPledges = await GetProjects(pledgeTier.ID);
                        for (let curPledge of curPledges){
                            prog += pledgeTier.Amount;
                        }
                    }
                    
                    let donos = await GetDonos(project.ID);
                    for (let donation of donos) {
                        prog+=donation.Amount;
                    }
                    
                    //console.log(prog);
                    if (prog < project.Goal && (project.IsActive < 2)){
                        await UpdateActive (project.ID, 3);
                        
                        let tiers = await GetTiers(project.ID);
                        for (let pledgeTier of tiers) {
                            //console.log(pledgeTier);
                            let curPledges = await GetProjects(pledgeTier.ID);
                            for (let curPledge of curPledges){
                                let money = await GetMoney(curPledge.SupporterID);
                                money = await SetMoney(parseInt(money.Budget, 10) + parseInt(pledgeTier.Amount, 10), curPledge.SupporterID);
                            }
                        }
                        
                        let donos = await GetDonos(project.ID);
                        for (let donation of donos) {
                            let money = await GetMoney(donation.SupporterID);
                            money = await SetMoney(parseInt(money.Budget, 10) + parseInt(donation.Amount, 10), donation.SupporterID);
                        }
                        
                        
                    } else if (prog >= project.Goal) {
                        await UpdateActive (project.ID, 2);
                    }
                    
                }
                
                
            }
            
            
            theProj = await GetProject(theWord);
            for (let project of body) {
                let returnName = await GetName(project.DesignerID);
               delete project.DesignerID;
               project.DesignerName = returnName.Email;
                
                
            }
            
            
            
        } catch (error) {
            console.log("ERROR: " + error);
            response.statusCode = 400;
            response.error = error;
        }
        
        
        
        //database stuff /\
        
        
       
        
        
    } catch(err){
        status = 400;
        body["error"] = err.toString();
    }
    
    //full response
    response = {
        'statusCode': status,
        
        headers: {
            "Access-Control-Allow-Headers" : "Content-Type",
            "Access-Control-Allow-Origin" : "*", //allow from anywhere
            "Access-Control-Allow-Methods" : "POST" //allow POSTs
        },
        
        'body': JSON.stringify(body),
    };

    return response;
};