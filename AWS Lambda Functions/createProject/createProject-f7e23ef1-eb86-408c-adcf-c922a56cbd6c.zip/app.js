let response;

const mysql = require("mysql");
let theWord;
let theProjID;

var con = mysql.createConnection({
  host: "calculatordb.cfj2ikzeeddv.us-east-1.rds.amazonaws.com",
  user: "calcAdmin",
  password: "MoundDay!",
  database: "info"
});

exports.lambdaHandler = async (event, context) => {
    let status;
    let body = {};
    
    
    try {
        
        //console.log(event);
        
        let info = event;
        
        let em = info.Email;
        //let em = "matt";
        
        //database stuff \/
        
        let game;
        let GetWord = (game) => {
            return new Promise((resolve, reject) => {
                con.query("SELECT ID FROM Designers WHERE Email=?", [em], (error, rows) => {
                    if (error) { return reject(error); }
                    if ((rows) && (rows.length != 0)) {
                        return resolve(rows[0]);   // TRUE if does exist
                    } else { 
                        throw "designer doesn't exist";
                    }
                });
            });
        };
        let GetProject = (game) => {
            return new Promise((resolve, reject) => {
                con.query("INSERT INTO Projects (ID, Name, Description, DesignerID, IsActive, Deadline, Genre, Goal) VALUES (UUID(), '" + info.Name + "', '" + info.Description + "', '" + theWord.ID + "', 0, '" + info.Deadline + "', '" + info.Genre + "', " + info.Goal + ");", (error, rows) => {
                    if (error) { return reject(error); }
                    return resolve(rows);
                });
            });
        };
        let GetprojID = (game) => {
            return new Promise((resolve, reject) => {
                con.query("SELECT * FROM info.Projects WHERE Name = '" + info.Name + "' UNION SELECT * FROM info.Projects WHERE Description = '" + info.Description + "';", (error, rows) => {
                    if (error) { return reject(error); }
                    if ((rows) && (rows.length != 0)) {
                        return resolve(rows[0]);   // TRUE if does exist
                    } else { 
                        throw "designer doesn't exist";
                    }
                });
            });
        };
        
        let GetName = (game) => {
            return new Promise((resolve, reject) => {
                con.query("SELECT Email FROM Designers WHERE ID=?", [theProjID.DesignerID], (error, rows) => {
                    if (error) { return reject(error); }
                    if ((rows) && (rows.length == 1)) {
                        return resolve(rows[0]);   // TRUE if does exist
                    } else { 
                        throw "designer doesn't exist";
                        return resolve("");   // FALSE if doesn't exist
                    }
                });
            });
        };
        
        try {
            theWord = await GetWord(0);
            let theProj = await GetProject(theWord);
            theProjID = await GetprojID(theWord);
            let returnName = await GetName(theWord);
            
            //console.log(theWord);
            
            body.ID = theProjID.ID;
            body.Name = info.Name;
            body.Description = info.Description;
            body.DesignerName = returnName.Email;
            body.IsActive = 0;
            body.Deadline = info.Deadline;
            body.Genre = info.Genre;
            body.Goal = info.Goal;
            body.PledgeTiers = [];
            body.Donations = [];
            
        } catch (error) {
            console.log("ERROR: " + error);
            response.statusCode = 400;
            response.error = error;
        }
        

        
        
        //let result = db.query("SELECT EXISTS(SELECT * FROM Designers WHERE Email = '" + em + "')" );
        //console.log(result);
        
        
        
        //database stuff /\
        
        
       
        
        
    } catch(err){
        status = 400;
        body["error"] = err.toString();
    }
    
    //full response
    response = {
        'statusCode': status,
        
        headers: {
            "Access-Control-Allow-Headers" : "Content-Type",
            "Access-Control-Allow-Origin" : "*", //allow from anywhere
            "Access-Control-Allow-Methods" : "POST" //allow POSTs
        },
        
        'body': JSON.stringify(body),
    };

    return response;
};