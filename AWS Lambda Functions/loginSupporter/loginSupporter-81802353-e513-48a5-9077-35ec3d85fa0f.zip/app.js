let response;

const mysql = require("mysql");

var con = mysql.createConnection({
  host: "calculatordb.cfj2ikzeeddv.us-east-1.rds.amazonaws.com",
  user: "calcAdmin",
  password: "MoundDay!",
  database: "info"
});

let theWord;

exports.lambdaHandler = async (event, context) => {
    let status;
    let body = {};
    
    
    try {
        
        //console.log(event);
        
        // let actual_event = event.body;
        // let info = JSON.parse(actual_event);
        let info = event;
        
        let em = info.Email;
        
        
        //let em = "matt";
        
        //database stuff \/
        
        let game;
        let GetWord = (game) => {
            return new Promise((resolve, reject) => {
                con.query("SELECT ID FROM Supporters WHERE Email=?", [em], (error, rows) => {
                    if (error) { return reject(error); }
                    if ((rows) && (rows.length == 1)) {
                        return resolve(rows[0]);   // TRUE if does exist
                    } else { 
                        throw "designer doesn't exist";
                        return resolve("");   // FALSE if doesn't exist
                    }
                });
            });
        };
        let GetNames = (game) => {
            console.log("THIS: " + game);
            return new Promise((resolve, reject) => {
                con.query("SELECT Email FROM Designers WHERE ID =?", [game], (error, rows) => {
                    if (error) { return reject(error); }
                    
                    if ((rows) && (rows.length == 1)) {
                        return resolve(rows[0]);   // TRUE if does exist
                    } else { 
                        throw "Supporter doesn't exist";
                        return resolve("");   // FALSE if doesn't exist
                    }
                });
            });
        };
        
        let GetProject = (game) => {
            return new Promise((resolve, reject) => {
                con.query("SELECT * FROM Projects WHERE IsActive = 1 OR IsActive = 2", (error, rows) => {
                    if (error) { return reject(error); }
                    body = rows;
                    return resolve(rows);
                });
            });
        };
        
        try {
            theWord = await GetWord(0);
            console.log("result: " + theWord);
            let theProj = await GetProject(theWord);
            
            
            for (let project of body) {
                let returnName = await GetNames(project.DesignerID);
               delete project.DesignerID;
               project.DesignerName = returnName.Email;
                
                
            }
            
            
            
        } catch (error) {
            console.log("ERROR: " + error);
            response.statusCode = 400;
            response.error = error;
        }

        
        
        // con.connect(function(err) {
        //     if (err) throw err;
        //     console.log("Connected!");
        //     con.query("SELECT EXISTS(SELECT * FROM Designers WHERE Email = '" + em + "')", function (err, result) {
        //         if (err) throw err;
        //         console.log("Result: " + result);
                
                
                
                
        //         if (result === 0){
        //             body["projectList"] = [];
        //             con.query("INSERT INTO Designers(ID, Email) VALUES (UUID(), '" + em + "')"); //test to make sure ''s aren't getting added to db
        //         } else {
        //             throw "designer already exists";
        //         }
                
                
            
        //         return response;
                
                
                
        //       });
        // });
        

        
        
        //let result = db.query("SELECT EXISTS(SELECT * FROM Designers WHERE Email = '" + em + "')" );
        //console.log(result);
        
        
        
        //database stuff /\
        
        
       
        
        
    } catch(err){
        status = 400;
        body["error"] = err.toString();
    }
    
    //full response
    response = {
        'statusCode': status,
        
        headers: {
            "Access-Control-Allow-Headers" : "Content-Type",
            "Access-Control-Allow-Origin" : "*", //allow from anywhere
            "Access-Control-Allow-Methods" : "POST" //allow POSTs
        },
        
        'body': JSON.stringify(body),
    };

    return response;
};