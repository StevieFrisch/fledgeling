let response;

const mysql = require("mysql");
let theWord;
let returnPlej;

var con = mysql.createConnection({
  host: "calculatordb.cfj2ikzeeddv.us-east-1.rds.amazonaws.com",
  user: "calcAdmin",
  password: "MoundDay!",
  database: "info"
});

exports.lambdaHandler = async (event, context) => {
    let status;
    let body = {};
    
    
    try {
        
        //console.log(event);
        
        let info = event;
        
        let em = info.Email;
        let id = info.ID;
        
        //database stuff \/
        
        let game;
        let GetWord = (game) => {
            return new Promise((resolve, reject) => {
                con.query("SELECT * FROM Supporters WHERE Email=?", [em], (error, rows) => {
                    if (error) { return reject(error); }
                    if ((rows) && (rows.length != 0)) {
                        return resolve(rows[0]);   // TRUE if does exist
                    } else { 
                        throw "designer doesn't exist";
                    }
                });
            });
        };

        let GetReturnPlej = (game) => {
            return new Promise((resolve, reject) => {
                con.query("SELECT * FROM PledgeTier WHERE ID=?", [id], (error, rows) => {
                    if (error) { return reject(error); }
                    if ((rows) && (rows.length != 0)) {
                        return resolve(rows[0]);   // TRUE if does exist
                    } else { 
                        throw "PledgeTier doesn't exist"
                    }
                });
            });
        };
        
        let GetReturnPlejs = (game) => {
            return new Promise((resolve, reject) => {
                con.query("SELECT * FROM Pledges WHERE PledgeTierID=?", [id], (error, rows) => {
                    if (error) { return reject(error); }
                    if ((rows) && (rows.length != 0)) {
                        return resolve(rows);   // TRUE if does exist
                    } else { 
                        return resolve([]);
                    }
                });
            });
        };
        
        let GetOwned = (game) => {
            return new Promise((resolve, reject) => {
                con.query("SELECT * FROM Pledges WHERE PledgeTierID = '" + id + "' AND SupporterID = '" + theWord.ID + "'", (error, rows) => {
                    if (error) { return reject(error); }
                    if ((rows) && (rows.length != 0)) {
                        return resolve(rows);   // TRUE if does exist
                    } else { 
                        return resolve([]);
                    }
                });
            });
        };
        
        let SubtractFunds = (game) => {
            return new Promise((resolve, reject) => {
                con.query("Update Supporters SET Budget = " + (theWord.Budget - returnPlej.Amount)  + " WHERE ID = '" + theWord.ID + "'", (error, rows) => {
                    if (error) { return reject(error); }
                    return resolve(rows);
                });
            });
        };
        
        let ClaimPledge = (game) => {
            return new Promise((resolve, reject) => {
                con.query("INSERT INTO Pledges (ID, SupporterID, PledgeTierID) VALUES (UUID(), '" + theWord.ID + "', '" + returnPlej.ID + "');", (error, rows) => {
                    if (error) { return reject(error); }
                    return resolve(rows);
                });
            });
        };
        
        try {
            theWord = await GetWord(0);
            returnPlej = await GetReturnPlej(theWord);
            let returnPlejs = await GetReturnPlejs(theWord);
            let owned = await GetOwned(theWord);
            
            if (owned.length < 1 &&  theWord.Budget >= returnPlej.Amount && returnPlejs.length < returnPlej.MaxSupporters) {// if NOT owned AND budget >= pledge amount AND numSupporters < MaxSupporters
            
                await SubtractFunds();
                await ClaimPledge();
            
            } else {
                if (owned.length > 0) {
                    throw "pledge already owned";
                } else if (theWord.Budget < returnPlej.Amount) {
                    throw "insufficient supporter funds";
                } else if (returnPlejs.length >= returnPlej.MaxSupporters) {
                    throw "pledge tier supporter maximum reached";
                } else {
                    throw "unknown error";
                }
            }
            
            body.ID = returnPlej.ID;
            body.Description = returnPlej.Description;
            body.ProjectID = returnPlej.ProjectID;
            body.MaxSupporters = returnPlej.MaxSupporters;
            body.CurrentSupporters = (returnPlejs.length + 1);
            body.Amount = returnPlej.Amount;
            body.CurrentSupporterBudget = (theWord.Budget - returnPlej.Amount);
            body.Owned = 1;
            
            
            
            //console.log(theWord);
            
            
            
        } catch (error) {
            console.log("ERROR: " + error);
            response.statusCode = 400;
            response.error = error;
        }
        

        
        
        //let result = db.query("SELECT EXISTS(SELECT * FROM Designers WHERE Email = '" + em + "')" );
        //console.log(result);
        
        
        
        //database stuff /\
        
        
       
        
        
    } catch(err){
        status = 400;
        body["error"] = err.toString();
    }
    
    //full response
    response = {
        'statusCode': status,
        
        headers: {
            "Access-Control-Allow-Headers" : "Content-Type",
            "Access-Control-Allow-Origin" : "*", //allow from anywhere
            "Access-Control-Allow-Methods" : "POST" //allow POSTs
        },
        
        'body': JSON.stringify(body),
    };

    return response;
};