let response;

const mysql = require("mysql");
let theWord;
let theWords;

var con = mysql.createConnection({
  host: "calculatordb.cfj2ikzeeddv.us-east-1.rds.amazonaws.com",
  user: "calcAdmin",
  password: "MoundDay!",
  database: "info"
});

exports.lambdaHandler = async (event, context) => {
    let status;
    let body = {};
    let returnName;
    
    
    try {
        
        //console.log(event);
        
        let info = event;
        
        let id = info.ID;
        //let em = "matt";
        
        //database stuff \/
        
        let game;

        let GetProject = (game) => {
            return new Promise((resolve, reject) => {
                con.query("Update Projects SET IsActive = 1 WHERE ID=?", [id], (error, rows) => {
                    if (error) { return reject(error); }
                    if ((rows) && (rows.length != 0)) {
                        return resolve(rows);   // TRUE if does exist
                    } else { 
                        return resolve ([]);
                    }
                });
            });
        };
        
        let GetWord = (game) => {
            return new Promise((resolve, reject) => {
                con.query("SELECT * FROM Projects WHERE ID=?", [id], (error, rows) => {
                    if (error) { return reject(error); }
                    if ((rows) && (rows.length != 0)) {
                        return resolve(rows[0]);   // TRUE if does exist
                    } else { 
                        throw "project doesn't exist";
                    }
                });
            });
        };
        
        let GetProjects = (game) => {
            return new Promise((resolve, reject) => {
                con.query("SELECT * FROM PledgeTier WHERE ProjectID=?", [id], (error, rows) => {
                    if (error) { return reject(error); }
                    if ((rows) && (rows.length != 0)) {
                        return resolve(rows);   // TRUE if does exist
                    } else { 
                        return resolve ([]);
                    }
                });
            });
        };
        
        let GetNames = (game) => {
            return new Promise((resolve, reject) => {
                con.query("SELECT Email FROM Designers WHERE ID=?", [theWords.DesignerID], (error, rows) => {
                    if (error) { return reject(error); }
                    if ((rows) && (rows.length == 1)) {
                        return resolve(rows[0]);   // TRUE if does exist
                    } else { 
                        throw "designer doesn't exist";
                        return resolve("");   // FALSE if doesn't exist
                    }
                });
            });
        };
        
        let GetDonos = (game) => {
            return new Promise((resolve, reject) => {
                con.query("SELECT * FROM Donations WHERE ProjectID=?", [id], (error, rows) => {
                    if (error) { return reject(error); }
                    if ((rows) && (rows.length != 0)) {
                        return resolve(rows);   // TRUE if does exist
                    } else { 
                        return resolve ([]);
                    }
                });
            });
        };
        
        try {
            theWord = await GetWord(0);
            let theProj = await GetProject(theWord);
            theWords = await GetWord(0);
            let theProjs = await GetProjects(theWord);
            let returnNames = await GetNames(theWord);
            
            body.ID = id;
            body.Name = theWords.Name;
            body.Description = theWords.Description;
            body.DesignerName = returnNames.Email;
            body.IsActive = theWords.IsActive;
            body.Deadline = theWords.Deadline;
            body.Genre = theWords.Genre;
            body.Goal = theWords.Goal;
            body.Amount = 0;
            body.PledgeTiers = theProjs;
            body.Donations = [];
            
            
            let prog = 0;
            for (let pledgeTier of theProjs) {
                //console.log(pledgeTier);
                let curPledges = await GetProjects(pledgeTier.ID);
                for (let curPledge of curPledges){
                    prog += pledgeTier.Amount;
                }
            }
            
            let donos = await GetDonos();
            for (let donation of donos) {
                //console.log(pledgeTier);
                prog+=donation.Amount;
                let curDono = {};
                curDono.Email = (await GetNames(donation.SupporterID)).Email;
                curDono.Amount = donation.Amount;
                body.Donations.push(curDono);
            }
            
            body.Amount = prog;
            
            
            //console.log(returnName);
            
            //console.log(theWord);
            
            
        } catch (error) {
            console.log("ERROR: " + error);
            response.statusCode = 400;
            response.error = error;
        }
        

        
        
        //let result = db.query("SELECT EXISTS(SELECT * FROM Designers WHERE Email = '" + em + "')" );
        //console.log(result);
        
        
        
        //database stuff /\
        
        
       
        
        
    } catch(err){
        status = 400;
        body["error"] = err.toString();
    }
    
    //full response
    response = {
        'statusCode': status,
        
        headers: {
            "Access-Control-Allow-Headers" : "Content-Type",
            "Access-Control-Allow-Origin" : "*", //allow from anywhere
            "Access-Control-Allow-Methods" : "POST" //allow POSTs
        },
        
        'body': JSON.stringify(body),
    };

    return response;
};