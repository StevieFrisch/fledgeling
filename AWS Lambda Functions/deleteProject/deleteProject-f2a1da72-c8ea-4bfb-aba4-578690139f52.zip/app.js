let response;

const mysql = require("mysql");
let theWord;

var con = mysql.createConnection({
  host: "calculatordb.cfj2ikzeeddv.us-east-1.rds.amazonaws.com",
  user: "calcAdmin",
  password: "MoundDay!",
  database: "info"
});

exports.lambdaHandler = async (event, context) => {
    let status;
    let body = {};
    let returnName;
    
    
    try {
        
        //console.log(event);
        
        let info = event;
        
        let id = info.ID;
        let em = info.Email;
        //let em = "matt";
        
        //database stuff \/
        
        let game;
        let GetWord = (game) => {
            return new Promise((resolve, reject) => {
                con.query("DELETE FROM Projects WHERE ID=?", [id], (error, rows) => {
                    if (error) { return reject(error); }
                    if ((rows) && (rows.length != 0)) {
                        return resolve(rows[0]);   // TRUE if does exist
                    } else { 
                        throw "project doesn't exist";
                    }
                });
            });
        };
        let GetProject = (game) => {
            return new Promise((resolve, reject) => {
                con.query("DELETE FROM PledgeTier WHERE ProjectID=?", [id], (error, rows) => {
                    if (error) { return reject(error); }
                    if ((rows) && (rows.length != 0)) {
                        return resolve(rows);   // TRUE if does exist
                    } else { 
                        return resolve ([]);
                    }
                });
            });
        };
        
        let GetName = (game) => {
            return new Promise((resolve, reject) => {
                con.query("SELECT ID FROM Designers WHERE Email=?", [em], (error, rows) => {
                    if (error) { return reject(error); }
                    if ((rows) && (rows.length == 1)) {
                        return resolve(rows[0]);   // TRUE if does exist
                    } else { 
                        return resolve("");   // FALSE if doesn't exist
                    }
                });
            });
        };
        
        let GetProjects = (game) => {
            return new Promise((resolve, reject) => {
                con.query("SELECT * FROM Projects WHERE DesignerID=?", [returnName.ID], (error, rows) => {
                    if (error) { return reject(error); }
                    body = rows;
                    return resolve(rows);
                });
            });
        };
        
        let GetProjs = (game) => {
            return new Promise((resolve, reject) => {
                con.query("SELECT * FROM Projects", (error, rows) => {
                    if (error) { return reject(error); }
                    body = rows;
                    return resolve(rows);
                });
            });
        };
        
        let GetNames = (game) => {
            //console.log("THIS: " + game);
            return new Promise((resolve, reject) => {
                con.query("SELECT Email FROM Designers WHERE ID =?", [game], (error, rows) => {
                    if (error) { return reject(error); }
                    
                    if ((rows) && (rows.length == 1)) {
                        return resolve(rows[0]);   // TRUE if does exist
                    } else { 
                        throw "Supporter doesn't exist";
                        return resolve("");   // FALSE if doesn't exist
                    }
                });
            });
        };
        
        try {
            theWord = await GetWord(0);
            let theProj = await GetProject(theWord);
            returnName = await GetName(theWord);
            let theProjs
            if (returnName != ""){
                theProjs = await GetProjects(theWord);
            } else {
                theProjs = await GetProjs(theWord);
                for (let project of body) {
                    let returnName = await GetNames(project.DesignerID);
                   delete project.DesignerID;
                   project.DesignerName = returnName.Email;
                    
                    
                }
            }
            
            
            //console.log(returnName);
            
            //console.log(theWord);
            
            
        } catch (error) {
            console.log("ERROR: " + error);
            response.statusCode = 400;
            response.error = error;
        }
        

        
        
        //let result = db.query("SELECT EXISTS(SELECT * FROM Designers WHERE Email = '" + em + "')" );
        //console.log(result);
        
        
        
        //database stuff /\
        
        
       
        
        
    } catch(err){
        status = 400;
        body["error"] = err.toString();
    }
    
    //full response
    response = {
        'statusCode': status,
        
        headers: {
            "Access-Control-Allow-Headers" : "Content-Type",
            "Access-Control-Allow-Origin" : "*", //allow from anywhere
            "Access-Control-Allow-Methods" : "POST" //allow POSTs
        },
        
        'body': JSON.stringify(body),
    };

    return response;
};