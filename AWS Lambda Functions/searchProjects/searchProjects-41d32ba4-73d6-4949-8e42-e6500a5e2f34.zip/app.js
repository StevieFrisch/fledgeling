let response;

const mysql = require("mysql");

var con = mysql.createConnection({
  host: "calculatordb.cfj2ikzeeddv.us-east-1.rds.amazonaws.com",
  user: "calcAdmin",
  password: "MoundDay!",
  database: "info"
});

let theWord;

exports.lambdaHandler = async (event, context) => {
    let status;
    let body = {};
    
    
    try {
        
        //console.log(event);
        
        // let actual_event = event.body;
        // let info = JSON.parse(actual_event);
        let info = event;
        
        let genre = info.Genre;
        let keyword = info.Keyword;
        
        
        //let em = "matt";
        
        //database stuff \/
        
        let game;
        
        let GetNames = (game) => {
            //console.log("THIS: " + game);
            return new Promise((resolve, reject) => {
                con.query("SELECT Email FROM Designers WHERE ID =?", [game], (error, rows) => {
                    if (error) { return reject(error); }
                    
                    if ((rows) && (rows.length == 1)) {
                        return resolve(rows[0]);   // TRUE if does exist
                    } else { 
                        throw "Supporter doesn't exist";
                        return resolve("");   // FALSE if doesn't exist
                    }
                });
            });
        };
        
        let GetProject = (game) => {
            return new Promise((resolve, reject) => {
                con.query("SELECT * FROM Projects WHERE IsActive = 1", (error, rows) => {
                    if (error) { return reject(error); }
                    //body = rows;
                    return resolve(rows);
                });
            });
        };
        
        let GetProjects = (game, val1, val2, val3) => {
            return new Promise((resolve, reject) => {
                con.query("SELECT * FROM Projects WHERE IsActive = 1" + game, [val1, val2, val3], (error, rows) => {
                    if (error) { return reject(error); }
                    //body = rows;
                    return resolve(rows);
                });
            });
        };
        
        
        try {
            body = [];
            let theProj;
            if ( (genre == undefined || genre == "") && (keyword == undefined || keyword == "") ){
                console.log("neither");
                theProj = await GetProject(0);
                for (let project of theProj) {
                    body.push(project);
                }
            } else if ( (genre != undefined && genre != "") && (keyword != undefined && keyword != "") ) {
                console.log("both");
                theProj = await GetProjects(" AND Genre LIKE ? AND (Description LIKE ? OR Name LIKE ?)", genre, "%" + keyword + "%", "%" + keyword + "%");
                for (let project of theProj) {
                    body.push(project);
                }
            } else if (genre != undefined && genre != "") {
                console.log("genre");
                theProj = await GetProjects(" AND Genre LIKE ?", genre);
                for (let project of theProj) {
                    body.push(project);
                }
            } else if (keyword != undefined && keyword != "") {
                console.log("keyword");
                theProj = await GetProjects(" AND (Description LIKE ? OR Name LIKE ?)", "%" + keyword + "%", "%" + keyword + "%");
                for (let project of theProj) {
                    body.push(project);
                }
            }
        
            
            
            for (let project of body) {
                let returnName = await GetNames(project.DesignerID);
               delete project.DesignerID;
               project.DesignerName = returnName.Email;
                
                
            }
            
            
            
        } catch (error) {
            console.log("ERROR: " + error);
            response.statusCode = 400;
            response.error = error;
        }

        
        
        // con.connect(function(err) {
        //     if (err) throw err;
        //     console.log("Connected!");
        //     con.query("SELECT EXISTS(SELECT * FROM Designers WHERE Email = '" + em + "')", function (err, result) {
        //         if (err) throw err;
        //         console.log("Result: " + result);
                
                
                
                
        //         if (result === 0){
        //             body["projectList"] = [];
        //             con.query("INSERT INTO Designers(ID, Email) VALUES (UUID(), '" + em + "')"); //test to make sure ''s aren't getting added to db
        //         } else {
        //             throw "designer already exists";
        //         }
                
                
            
        //         return response;
                
                
                
        //       });
        // });
        

        
        
        //let result = db.query("SELECT EXISTS(SELECT * FROM Designers WHERE Email = '" + em + "')" );
        //console.log(result);
        
        
        
        //database stuff /\
        
        
       
        
        
    } catch(err){
        status = 400;
        body["error"] = err.toString();
    }
    
    //full response
    response = {
        'statusCode': status,
        
        headers: {
            "Access-Control-Allow-Headers" : "Content-Type",
            "Access-Control-Allow-Origin" : "*", //allow from anywhere
            "Access-Control-Allow-Methods" : "POST" //allow POSTs
        },
        
        'body': JSON.stringify(body),
    };

    return response;
};