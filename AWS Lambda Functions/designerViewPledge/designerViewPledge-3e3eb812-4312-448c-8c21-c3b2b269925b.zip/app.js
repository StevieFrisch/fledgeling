let response;

const mysql = require("mysql");

var con = mysql.createConnection({
  host: "calculatordb.cfj2ikzeeddv.us-east-1.rds.amazonaws.com",
  user: "calcAdmin",
  password: "MoundDay!",
  database: "info"
});

exports.lambdaHandler = async (event, context) => {
    let status;
    let body = {};
    
    
    try {
        
        //console.log(event);
        
        let info = event;
        
        let id = info.ID;
        //let em = "matt";
        
        //database stuff \/
        
        let game;

        let GetReturnPlej = (game) => {
            return new Promise((resolve, reject) => {
                con.query("SELECT * FROM PledgeTier WHERE ID=?", [id], (error, rows) => {
                    if (error) { return reject(error); }
                    if ((rows) && (rows.length != 0)) {
                        return resolve(rows[0]);   // TRUE if does exist
                    } else { 
                        throw "PledgeTier doesn't exist"
                    }
                });
            });
        };
        
        let GetReturnPlejs = (game) => {
            return new Promise((resolve, reject) => {
                con.query("SELECT * FROM Pledges WHERE PledgeTierID=?", [id], (error, rows) => {
                    if (error) { return reject(error); }
                    if ((rows) && (rows.length != 0)) {
                        return resolve(rows);   // TRUE if does exist
                    } else { 
                        return resolve([]);
                    }
                });
            });
        };
        
        let GetName = (game) => {
            return new Promise((resolve, reject) => {
                con.query("SELECT Email FROM Supporters WHERE ID=?", [game], (error, rows) => {
                    if (error) { return reject(error); }
                    if ((rows) && (rows.length == 1)) {
                        return resolve(rows[0]);   // TRUE if does exist
                    } else { 
                        throw "designer doesn't exist";   // FALSE if doesn't exist
                    }
                });
            });
        };
        
        try {
            let returnPlej = await GetReturnPlej(0);
            let returnPlejs = await GetReturnPlejs(0);
            
            body.ID = returnPlej.ID;
            body.Description = returnPlej.Description;
            body.ProjectID = returnPlej.ProjectID;
            body.Amount = returnPlej.Amount;
            body.MaxSupporters = returnPlej.MaxSupporters;
            body.CurrentSupporters = [];
            
            
            for (let pledges of returnPlejs){
                let em = await GetName (pledges.SupporterID);
                body.CurrentSupporters.push(em.Email);
            }
            
            
            //console.log(theWord);
            
            
            
        } catch (error) {
            console.log("ERROR: " + error);
            response.statusCode = 400;
            response.error = error;
        }
        

        
        
        //let result = db.query("SELECT EXISTS(SELECT * FROM Designers WHERE Email = '" + em + "')" );
        //console.log(result);
        
        
        
        //database stuff /\
        
        
       
        
        
    } catch(err){
        status = 400;
        body["error"] = err.toString();
    }
    
    //full response
    response = {
        'statusCode': status,
        
        headers: {
            "Access-Control-Allow-Headers" : "Content-Type",
            "Access-Control-Allow-Origin" : "*", //allow from anywhere
            "Access-Control-Allow-Methods" : "POST" //allow POSTs
        },
        
        'body': JSON.stringify(body),
    };

    return response;
};